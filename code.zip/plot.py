import numpy as np
import matplotlib.pyplot as plt

from functions import checkFilename

plt.rcParams["font.family"] = ["Times New Roman", "SimSun"]  # 英文字体为新罗马，中文字体为宋体
plt.rcParams["font.serif"] = ["Times New Roman", "SimSun"]  # 衬线字体
plt.rcParams["font.sans-serif"] = ["Times New Roman", "SimSun", "Arial", "SimHei"]  # 无衬线字体，与Latex相关
plt.rcParams["mathtext.fontset"] = "custom" # 设置LaTeX字体为用户自定义，这里演示，就不用computer modern了
plt.rcParams['axes.unicode_minus'] = False 


def plotReward(rewardSeq, eps:int=None, filename=None) -> None : 
    if eps is None :
        tSeq = range(len(rewardSeq))
    else :
        tSeq = range(eps)
        batch = len(rewardSeq) // eps
        rewardSeq = [sum(rewardSeq[i*batch : (i+1)*batch])/batch for i in tSeq]
    smoothedReward = [rewardSeq[0]]
    alpha = 0.9
    for i in range(1, len(rewardSeq)) : 
        # # 指数平滑
        smoothedValue = alpha*rewardSeq[i] + (1-alpha)*smoothedReward[i-1]
        smoothedReward.append(smoothedValue)
        # # ----------
        # 滑动窗口
        # windowLength = 50
        # if i < windowLength : smoothedReward.append(sum(rewardSeq[:i+1])/(i+1))
        # else : smoothedReward.append(sum(rewardSeq[i-windowLength+1:i+1])/windowLength)
        # ----------
    plt.figure(figsize=(20,10))
    plt.plot(tSeq, smoothedReward)
    # plt.title("loss curve")
    plt.xlabel("训练集数")
    plt.ylabel(r"$loss$")
    if filename is not None : 
        filename = checkFilename(filename)
        plt.savefig(filename)


def plotTrajectory(x_seq, x_hat_seq, STATUS="None") -> None:
    x_seq = np.array(x_seq)
    x_hat_seq = np.array(x_hat_seq)
    ds = x_seq[0].size
    max_steps = len(x_seq)
    t_seq = range(max_steps)
    error = np.abs(x_seq - x_hat_seq)
    fig, axs = plt.subplots(ds,1)
    for i in range(ds) : 
        ax = axs[i] if ds > 1 else axs
        ax.plot(t_seq, x_seq.T[i], label='x_real', color='blue', linestyle='-') #, 'o'
        ax.plot(t_seq, x_hat_seq.T[i], label='x_hat', color='red', linestyle='-')#, 'o'
        ax.set_xlim(0, max_steps)
        ax.set_ylabel(f'x{i+1}')
        ax.xaxis.set_visible(False)
        ax.grid(True)
    # axs[0].set_title(f'{STATUS}')
    if ds > 1:
        axs[0].set_title(f'{STATUS}状态估计效果图')
        axs[0].legend()
        axs[-1].set_xlabel('时间步')
        axs[-1].xaxis.set_visible(True)
    else :
        axs.set_title(f'{STATUS}状态估计效果图')
        axs.legend()
        axs.set_xlabel('时间步')
        axs.xaxis.set_visible(True)

    fig, axs = plt.subplots(ds,1)
    color = ['b','g','r','c','m','y','k']
    for i in range(ds) : 
        ax = axs[i] if ds > 1 else axs
        ax.plot(t_seq, error[:,i], label=f'x{i+1}', color='red', linestyle='--') #, 'o'
        ax.plot(t_seq, np.average(error[:,i])*np.ones_like(t_seq), color='blue')
        ax.legend()
        ax.xaxis.set_visible(False)
        ax.grid(True)
    if ds > 1:
        axs[0].set_title(f'{STATUS}误差绝对值')
        axs[-1].set_xlabel('时间步')
        axs[-1].xaxis.set_visible(True)
    else :
        axs.set_title(f'{STATUS}误差绝对值')
        axs.set_xlabel('时间步')
        axs.xaxis.set_visible(True)

    # fig = plt.figure()
    # ax = plt.axes(projection='3d')
    # ax.plot3D(x_seq[:,0], x_seq[:,1], x_seq[:,2], label='x_real', color='blue')
    # ax.scatter(*x_seq[0], marker='o', color='blue')
    # ax.plot3D(x_hat_seq[:,0], x_hat_seq[:,1], x_hat_seq[:,2], label='x_hat', color='red')
    # ax.scatter(*x_hat_seq[0], marker='o', color='red')
    # ax.set_xlabel('x1')
    # ax.set_ylabel('x2')
    # ax.set_zlabel('x3')
    # ax.legend()
    # ax.set_title('状态轨迹')

def plotStepMSE(isSave=False):
    '''有些参数需要手动调'''
    import pickle
    with open(file="data/EKF-MHE(1).bin", mode="rb") as f:
        xhat_batch_MHE1 = pickle.load(f)
    with open(file="data/EKF-MHE(2).bin", mode="rb") as f:
        xhat_batch_MHE2 = pickle.load(f)
    with open(file="data/EKF-MHE(3).bin", mode="rb") as f:
        xhat_batch_MHE3 = pickle.load(f)
    with open(file="data/EKF-MHE(4).bin", mode="rb") as f:
        xhat_batch_MHE4 = pickle.load(f)
    with open(file="data/EKF-MHE(5).bin", mode="rb") as f:
        xhat_batch_MHE5 = pickle.load(f)
    with open(file="data/EKF-MHE(6).bin", mode="rb") as f:
        xhat_batch_MHE6 = pickle.load(f)
    with open(file="data/EKF.bin", mode="rb") as f:
        xhat_batch_EKF = pickle.load(f)
    with open(file="data/RA-MHE.bin", mode="rb") as f:
        xhat_batch_RA = pickle.load(f)
    with open(file="data/Continuous1_steps100_episodes50_randomSeed10086.bin", mode="rb") as f:
        trajs = pickle.load(f)
        x_batch = trajs["x_batch"]
    xhat_batch_EKF = np.array(xhat_batch_EKF)
    xhat_batch_MHE1 = np.array(xhat_batch_MHE1)
    xhat_batch_MHE2 = np.array(xhat_batch_MHE2)
    xhat_batch_MHE3 = np.array(xhat_batch_MHE3)
    xhat_batch_MHE4 = np.array(xhat_batch_MHE4)
    xhat_batch_MHE5 = np.array(xhat_batch_MHE5)
    xhat_batch_MHE6 = np.array(xhat_batch_MHE6)
    xhat_batch_RA = np.array(xhat_batch_RA)
    x_batch = np.array(x_batch)

    # step MSE
    e_EKF = np.mean(np.sum(np.square(xhat_batch_EKF-x_batch), axis=-1), axis=0)
    e_MHE1 = np.mean(np.sum(np.square(xhat_batch_MHE1-x_batch), axis=-1), axis=0)
    e_MHE2 = np.mean(np.sum(np.square(xhat_batch_MHE2-x_batch), axis=-1), axis=0)
    e_MHE3 = np.mean(np.sum(np.square(xhat_batch_MHE3-x_batch), axis=-1), axis=0)
    e_MHE4 = np.mean(np.sum(np.square(xhat_batch_MHE4-x_batch), axis=-1), axis=0)
    e_MHE5 = np.mean(np.sum(np.square(xhat_batch_MHE5-x_batch), axis=-1), axis=0)
    e_MHE6 = np.mean(np.sum(np.square(xhat_batch_MHE6-x_batch), axis=-1), axis=0)
    e_RA = np.mean(np.sum(np.square(xhat_batch_RA-x_batch), axis=-1), axis=0)
    t_seq = range(1,len(e_EKF)+1)
    fig, (ax1, ax2) = plt.subplots(1,2, figsize=(20,15), sharey=True)
    # 设置每个子图的x轴范围
    ax1.set_xlim(1, 10)
    ax2.set_xlim(80, 100)
    # 确保x轴只显示整数
    from matplotlib.ticker import MaxNLocator
    ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
    # 绘制图像
    ax1.plot(t_seq, e_EKF, 'o', label='EKF', color='blue', linestyle='-')
    ax1.plot(t_seq, e_MHE1, 'o', label='MHE1', color='red', linestyle='-')
    ax1.plot(t_seq, e_MHE2, 'o', label='MHE2', color='green', linestyle='-')
    ax1.plot(t_seq, e_MHE3, 'o', label='MHE3', color='purple', linestyle='-')
    ax1.plot(t_seq, e_MHE4, 'o', label='MHE4', color='orange', linestyle='-')
    ax1.plot(t_seq, e_MHE5, 'o', label='MHE5', color='black', linestyle='-')
    # ax1.plot(t_seq, e_MHE6, 'o', label='MHE6', color='yellow', linestyle='-')
    ax1.plot(t_seq, e_RA, 'o', label='RA-MHE', color='cyan', linestyle='-')
    ax2.plot(t_seq, e_EKF, 'o', label='EKF', color='blue', linestyle='-')
    ax2.plot(t_seq, e_MHE1, 'o', label='MHE1', color='red', linestyle='-')
    ax2.plot(t_seq, e_MHE2, 'o', label='MHE2', color='green', linestyle='-')
    ax2.plot(t_seq, e_MHE3, 'o', label='MHE3', color='purple', linestyle='-')
    ax2.plot(t_seq, e_MHE4, 'o', label='MHE4', color='orange', linestyle='-')
    ax2.plot(t_seq, e_MHE5, 'o', label='MHE5', color='black', linestyle='-')
    # ax2.plot(t_seq, e_MHE6, 'o', label='MHE6', color='yellow', linestyle='-')
    ax2.plot(t_seq, e_RA, 'o', label='RA-MHE', color='cyan', linestyle='-')
    ax1.set_yscale('log')
    ax1.grid(True)
    ax2.grid(True)
    ax2.legend()
    ax2.set_xlabel('time steps')
    ax1.set_ylabel(r'$e_t$')

    # 隐藏第二个子图的左边框和第一个子图的右边框
    ax1.spines['right'].set_visible(False)
    ax2.spines['left'].set_visible(False)
    # 添加斜线，表示轴是断裂的
    d = .015  # 斜线的长度
    kwargs = dict(transform=ax1.transAxes, color='k', clip_on=False)
    ax1.plot((1-d, 1+d), (-d, +d), **kwargs)  # 左下到右上
    ax1.plot((1-d, 1+d),(1-d, 1+d), **kwargs)  # 左上到右下
    kwargs.update(transform=ax2.transAxes)  # switch to the bottom axes
    ax2.plot((-d, +d), (1-d, 1+d), **kwargs)  # 右上到左下
    ax2.plot((-d, +d), (-d, +d), **kwargs)  # 右下到左上
    plt.subplots_adjust(wspace=0.1)
    if isSave:
        plt.savefig("picture/step_MSE.eps")
        # plt.savefig("picture/step_MSE.png")

def plotStateMSE(isSave=False):
    '''有些参数需要手动调'''
    import pickle
    with open(file="data/EKF-MHE(1).bin", mode="rb") as f:
        xhat_batch_MHE1 = pickle.load(f)
    with open(file="data/EKF-MHE(2).bin", mode="rb") as f:
        xhat_batch_MHE2 = pickle.load(f)
    with open(file="data/EKF-MHE(3).bin", mode="rb") as f:
        xhat_batch_MHE3 = pickle.load(f)
    with open(file="data/EKF-MHE(4).bin", mode="rb") as f:
        xhat_batch_MHE4 = pickle.load(f)
    with open(file="data/EKF-MHE(5).bin", mode="rb") as f:
        xhat_batch_MHE5 = pickle.load(f)
    with open(file="data/EKF-MHE(6).bin", mode="rb") as f:
        xhat_batch_MHE6 = pickle.load(f)
    with open(file="data/EKF.bin", mode="rb") as f:
        xhat_batch_EKF = pickle.load(f)
    with open(file="data/RA-MHE.bin", mode="rb") as f:
        xhat_batch_RA = pickle.load(f)
    with open(file="data/Continuous1_steps100_episodes50_randomSeed10086.bin", mode="rb") as f:
        trajs = pickle.load(f)
        x_batch = trajs["x_batch"]
    xhat_batch_EKF = np.array(xhat_batch_EKF)
    xhat_batch_MHE1 = np.array(xhat_batch_MHE1)
    xhat_batch_MHE2 = np.array(xhat_batch_MHE2)
    xhat_batch_MHE3 = np.array(xhat_batch_MHE3)
    xhat_batch_MHE4 = np.array(xhat_batch_MHE4)
    xhat_batch_MHE5 = np.array(xhat_batch_MHE5)
    xhat_batch_MHE6 = np.array(xhat_batch_MHE6)
    xhat_batch_RA = np.array(xhat_batch_RA)
    x_batch = np.array(x_batch)

    # estimation state
    xhat_seq_EKF = xhat_batch_EKF[0]
    xhat_seq_MHE1 = xhat_batch_MHE1[0]
    xhat_seq_MHE2 = xhat_batch_MHE2[0]
    xhat_seq_MHE3 = xhat_batch_MHE3[0]
    xhat_seq_MHE4 = xhat_batch_MHE4[0]
    xhat_seq_MHE5 = xhat_batch_MHE5[0]
    xhat_seq_MHE6 = xhat_batch_MHE6[0]
    xhat_seq_RA = xhat_batch_RA[0]
    x_seq = x_batch[0]
    t_seq = range(1,len(x_seq)+1)
    fig, axs = plt.subplots(3,2, figsize=(20,20), sharey=True)
    # 设置每个子图的x轴范围
    axs[0,0].set_xlim(1, 10)
    axs[1,0].set_xlim(1, 10)
    axs[2,0].set_xlim(1, 10)
    axs[0,1].set_xlim(80, 100)
    axs[1,1].set_xlim(80, 100)
    axs[2,1].set_xlim(80, 100)
    # 确保x轴只显示整数
    from matplotlib.ticker import MaxNLocator
    axs[0,0].xaxis.set_major_locator(MaxNLocator(integer=True))
    axs[1,0].xaxis.set_major_locator(MaxNLocator(integer=True))
    axs[2,0].xaxis.set_major_locator(MaxNLocator(integer=True))
    axs[0,1].xaxis.set_major_locator(MaxNLocator(integer=True))
    axs[1,1].xaxis.set_major_locator(MaxNLocator(integer=True))
    axs[2,1].xaxis.set_major_locator(MaxNLocator(integer=True))
    # 绘制图像
    axs[0,0].plot(t_seq, xhat_seq_EKF[:,0], 'o', label='EKF', color='blue', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_MHE1[:,0], 'o', label='MHE1', color='red', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_MHE2[:,0], 'o', label='MHE2', color='green', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_MHE3[:,0], 'o', label='MHE3', color='purple', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_MHE4[:,0], 'o', label='MHE4', color='orange', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_MHE5[:,0], 'o', label='MHE5', color='black', linestyle='-')
    # axs[0,0].plot(t_seq, xhat_seq_MHE6[:,0], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[0,0].plot(t_seq, xhat_seq_RA[:,0], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[0,0].plot(t_seq, x_seq[:,0], 'o', label='real', color='brown', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_EKF[:,0], 'o', label='EKF', color='blue', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_MHE1[:,0], 'o', label='MHE1', color='red', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_MHE2[:,0], 'o', label='MHE2', color='green', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_MHE3[:,0], 'o', label='MHE3', color='purple', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_MHE4[:,0], 'o', label='MHE4', color='orange', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_MHE5[:,0], 'o', label='MHE5', color='black', linestyle='-')
    # axs[0,1].plot(t_seq, xhat_seq_MHE6[:,0], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[0,1].plot(t_seq, xhat_seq_RA[:,0], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[0,1].plot(t_seq, x_seq[:,0], 'o', label='real', color='brown', linestyle='-')

    axs[1,0].plot(t_seq, xhat_seq_EKF[:,1], 'o', label='EKF', color='blue', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_MHE1[:,1], 'o', label='MHE1', color='red', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_MHE2[:,1], 'o', label='MHE2', color='green', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_MHE3[:,1], 'o', label='MHE3', color='purple', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_MHE4[:,1], 'o', label='MHE4', color='orange', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_MHE5[:,1], 'o', label='MHE5', color='black', linestyle='-')
    # axs[1,0].plot(t_seq, xhat_seq_MHE6[:,1], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[1,0].plot(t_seq, xhat_seq_RA[:,1], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[1,0].plot(t_seq, x_seq[:,1], 'o', label='real', color='brown', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_EKF[:,1], 'o', label='EKF', color='blue', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_MHE1[:,1], 'o', label='MHE1', color='red', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_MHE2[:,1], 'o', label='MHE2', color='green', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_MHE3[:,1], 'o', label='MHE3', color='purple', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_MHE4[:,1], 'o', label='MHE4', color='orange', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_MHE5[:,1], 'o', label='MHE5', color='black', linestyle='-')
    # axs[1,1].plot(t_seq, xhat_seq_MHE6[:,1], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[1,1].plot(t_seq, xhat_seq_RA[:,1], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[1,1].plot(t_seq, x_seq[:,1], 'o', label='real', color='brown', linestyle='-')

    axs[2,0].plot(t_seq, xhat_seq_EKF[:,2], 'o', label='EKF', color='blue', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_MHE1[:,2], 'o', label='MHE1', color='red', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_MHE2[:,2], 'o', label='MHE2', color='green', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_MHE3[:,2], 'o', label='MHE3', color='purple', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_MHE4[:,2], 'o', label='MHE4', color='orange', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_MHE5[:,2], 'o', label='MHE5', color='black', linestyle='-')
    # axs[2,0].plot(t_seq, xhat_seq_MHE6[:,2], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[2,0].plot(t_seq, xhat_seq_RA[:,2], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[2,0].plot(t_seq, x_seq[:,2], 'o', label='real', color='brown', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_EKF[:,2], 'o', label='EKF', color='blue', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_MHE1[:,2], 'o', label='MHE1', color='red', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_MHE2[:,2], 'o', label='MHE2', color='green', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_MHE3[:,2], 'o', label='MHE3', color='purple', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_MHE4[:,2], 'o', label='MHE4', color='orange', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_MHE5[:,2], 'o', label='MHE5', color='black', linestyle='-')
    # axs[2,1].plot(t_seq, xhat_seq_MHE6[:,2], 'o', label='MHE6', color='yellow', linestyle='-')
    axs[2,1].plot(t_seq, xhat_seq_RA[:,2], 'o', label='RA-MHE', color='cyan', linestyle='-')
    axs[2,1].plot(t_seq, x_seq[:,2], 'o', label='real', color='brown', linestyle='-')
    # ax1.set_yscale('log')
    axs[0,0].grid(True)
    axs[1,0].grid(True)
    axs[2,0].grid(True)
    axs[0,1].grid(True)
    axs[1,1].grid(True)
    axs[2,1].grid(True)
    axs[0,1].legend(ncol=2)
    axs[2,1].set_xlabel('时间步')
    axs[0,0].set_ylabel(r'$x(1)$')
    axs[1,0].set_ylabel(r'$x(2)$')
    axs[2,0].set_ylabel(r'$x(3)$')

    # 隐藏第二个子图的左边框和第一个子图的右边框
    axs[0,0].spines['right'].set_visible(False)
    axs[1,0].spines['right'].set_visible(False)
    axs[2,0].spines['right'].set_visible(False)
    axs[0,1].spines['left'].set_visible(False)
    axs[1,1].spines['left'].set_visible(False)
    axs[2,1].spines['left'].set_visible(False)
    # 添加斜线，表示轴是断裂的
    d = .015  # 斜线的长度
    kwargs = dict(transform=axs[0,0].transAxes, color='k', clip_on=False)
    axs[0,0].plot((1-d, 1+d), (-d, +d), **kwargs)  # 左下到右上
    kwargs = dict(transform=axs[1,0].transAxes, color='k', clip_on=False)
    axs[1,0].plot((1-d, 1+d), (-d, +d), **kwargs)  # 左下到右上
    kwargs = dict(transform=axs[2,0].transAxes, color='k', clip_on=False)
    axs[2,0].plot((1-d, 1+d), (-d, +d), **kwargs)  # 左下到右上
    kwargs = dict(transform=axs[0,0].transAxes, color='k', clip_on=False)
    axs[0,0].plot((1-d, 1+d),(1-d, 1+d), **kwargs)  # 左上到右下
    kwargs = dict(transform=axs[1,0].transAxes, color='k', clip_on=False)
    axs[1,0].plot((1-d, 1+d),(1-d, 1+d), **kwargs)  # 左上到右下
    kwargs = dict(transform=axs[2,0].transAxes, color='k', clip_on=False)
    axs[2,0].plot((1-d, 1+d),(1-d, 1+d), **kwargs)  # 左上到右下
    kwargs.update(transform=axs[0,1].transAxes)  # switch to the bottom axes
    axs[0,1].plot((-d, +d), (1-d, 1+d), **kwargs)  # 右上到左下
    kwargs.update(transform=axs[1,1].transAxes)  # switch to the bottom axes
    axs[1,1].plot((-d, +d), (1-d, 1+d), **kwargs)  # 右上到左下
    kwargs.update(transform=axs[2,1].transAxes)  # switch to the bottom axes
    axs[2,1].plot((-d, +d), (1-d, 1+d), **kwargs)  # 右上到左下
    kwargs.update(transform=axs[0,1].transAxes)  # switch to the bottom axes
    axs[0,1].plot((-d, +d), (-d, +d), **kwargs)  # 右下到左上
    kwargs.update(transform=axs[1,1].transAxes)  # switch to the bottom axes
    axs[1,1].plot((-d, +d), (-d, +d), **kwargs)  # 右下到左上
    kwargs.update(transform=axs[2,1].transAxes)  # switch to the bottom axes
    axs[2,1].plot((-d, +d), (-d, +d), **kwargs)  # 右下到左上
    plt.subplots_adjust(wspace=0.1)
    if isSave:
        plt.savefig("picture/state_estimations(CHS).eps")
        # plt.savefig("picture/state_estimations(CHS).png")

def plot3DTraj(isSave=False) :
    import pickle
    with open(file="data/Continuous1_steps1000_episodes1_randomSeed10086.bin", mode="rb") as f:
        trajs = pickle.load(f)
        x_batch = trajs["x_batch"]
    x_seq = np.array(x_batch[0])
    x = x_seq[:, 0]
    y = x_seq[:, 1]
    z = x_seq[:, 2]

    from mpl_toolkits.mplot3d import Axes3D
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')

    ax.plot3D(x, y, z, color='b', linewidth=2, linestyle="--")
    ax.set_xlabel(r'$x(1)$', labelpad=15)
    ax.set_ylabel(r'$x(2)$', labelpad=15)
    ax.set_zlabel(r'$x(3)$', labelpad=15)

    if isSave:
        plt.savefig("picture/Lorenz_attractor_3D_traj.eps")

if __name__ == "__main__" : 
    plt.rcParams['font.size'] = 28
    #region 绘制损失函数曲线
#     rewardSeq = [
# 15049.515625,
# 25292.6328125,
# 6197.07568359375,
# 6974.01123046875,
# 10330.556640625,
# 12139.6435546875,
# 6370.201171875,
# 7595.498046875,
# 7777.63330078125,
# 5931.6669921875,
# 5126.689453125,
# 3480.547119140625,
# 7651.068359375,
# 4543.73828125,
# 6834.966796875,
# 3950.968994140625,
# 4249.48583984375,
# 3371.355224609375,
# 1946.294189453125,
# 4183.75927734375,
# 4642.263671875,
# 2947.740478515625,
# 3413.835693359375,
# 2607.655517578125,
# 3244.961669921875,
# 3572.4130859375,
# 2530.66796875,
# 3173.771484375,
# 2441.986572265625,
# 2898.721923828125,
# 2563.3955078125,
# 2610.34814453125,
# 2308.833740234375,
# 1996.886474609375,
# 2777.59716796875,
# 2146.234619140625,
# 2272.1494140625,
# 2843.139892578125,
# 1579.5015869140625,
# 2119.155029296875,
# 1830.5472412109375,
# 1875.83544921875,
# 2490.4541015625,
# 1210.1881103515625,
# 1849.96435546875,
# 2800.543701171875,
# 1435.20751953125,
# 1825.099853515625,
# 1806.3798828125,
# 2580.838134765625,
# 1708.0623779296875,
# 1756.4796142578125,
# 1773.1187744140625,
# 1592.35302734375,
# 2028.3157958984375,
# 1980.454833984375,
# 2389.47802734375,
# 1927.6273193359375,
# 1696.614501953125,
# 1560.1351318359375,
# 1534.955078125,
# 776.1361694335938,
# 2450.54052734375,
# 823.0577392578125,
# 1428.48388671875,
# 1584.5174560546875,
# 1269.1590576171875,
# 1032.113037109375,
# 878.2066040039062,
# 1178.162353515625,
# 1348.2279052734375,
# 1586.2723388671875,
# 1429.858642578125,
# 1242.60009765625,
# 1285.802001953125,
# 1215.13037109375,
# 1314.22900390625,
# 1524.98779296875,
# 1230.689453125,
# 1104.3798828125,
# 1648.196044921875,
# 1502.435791015625,
# 1537.2545166015625,
# 1072.1070556640625,
# 1295.6767578125,
# 1552.4278564453125,
# 923.031005859375,
# 676.1568603515625,
# 993.9507446289062,
# 1326.403076171875,
# 1727.4486083984375,
# 1073.2462158203125,
# 1445.87255859375,
# 1527.7955322265625,
# 890.8605346679688,
# 2101.081787109375,
# 1310.4210205078125,
# 1295.4056396484375,
# 985.083251953125,
# 1249.6204833984375,
# 1344.2958984375,
# 1145.5975341796875,
# 1583.607177734375,
# 1081.1212158203125,
# 927.5148315429688,
# 1680.43896484375,
# 844.3330688476562,
# 1412.57763671875,
# 2610.281494140625,
# 543.8367309570312,
# 554.3704223632812,
# 611.892822265625,
# 1595.6180419921875,
# 1123.952880859375,
# 1283.5213623046875,
# 968.2113647460938,
# 886.6347045898438,
# 910.0780029296875,
# 1223.98681640625,
# 1064.023193359375,
# 1434.553466796875,
# 1006.406982421875,
# 1156.9442138671875,
# 1754.3218994140625,
# 3714.39453125,
# 652.08544921875,
# 747.533203125,
# 1051.8387451171875,
# 1721.686767578125,
# 1121.011962890625,
# 1548.8675537109375,
# 1448.22314453125,
# 1410.6461181640625,
# 1164.990966796875,
# 1044.5087890625,
# 992.9295654296875,
# 1183.064697265625,
# 1241.5247802734375,
# 964.2048950195312,
# 1150.229736328125,
# 1423.8653564453125,
# 1079.4110107421875,
# 970.9623413085938,
# 934.7562255859375,
# 1316.6993408203125,
# 899.9475708007812,
# 1185.1527099609375,
# 2521.611328125,
# 1970.2099609375,
# 1324.574462890625,
# 1534.5428466796875,
# 1603.710693359375,
# 1541.1126708984375,
# 1131.708740234375,
# 1407.4124755859375,
# 1311.9967041015625,
# 1366.7442626953125,
# 1034.2957763671875,
# 1322.037109375,
# 969.1363525390625,
# 2018.2147216796875,
# 945.7922973632812,
# 1210.1046142578125,
# 1116.4324951171875,
# 1813.709716796875,
# 888.636962890625,
# 1451.1226806640625,
# 1870.5791015625,
# 1086.284912109375,
# 1318.8887939453125,
# 1964.2794189453125,
# 1008.6729736328125,
# 1660.4537353515625,
# 1726.2147216796875,
# 909.8345947265625,
# 938.9195556640625,
# 1128.66650390625,
# 1265.2266845703125,
# 1154.657470703125,
# 1194.687255859375,
# 1657.05859375,
# 1222.5341796875,
# 755.426513671875,
# 1277.177978515625,
# 990.5191040039062,
# 951.8214111328125,
# 1373.4892578125,
# 658.0111694335938,
# 1571.2916259765625,
# 800.6446533203125,
# 908.0364990234375,
# 1013.5546875,
# 850.830322265625,
# 735.118896484375,
# 917.4255981445312,
# 2201.69970703125,
# 815.5631103515625,
# 863.883056640625,
# 1279.664794921875,
# 588.901611328125,
# 1445.2322998046875,
# 777.7606201171875,
# 750.9041137695312,
# 928.750732421875,
# 930.0643310546875,
# 1111.112548828125,
# 744.9208374023438,
# 2261.669921875,
# 1128.8294677734375,
# 965.84130859375,
# 1052.4774169921875,
# 845.500732421875,
# 566.1401977539062,
# 843.2138061523438,
# 601.0835571289062,
# 920.0454711914062,
# 994.118896484375,
# 1055.9796142578125,
# 530.2438354492188,
# 1084.791259765625,
# 974.905517578125,
# 635.7202758789062,
# 1469.966552734375,
# 598.5072021484375,
# 1572.90771484375,
# 558.579345703125,
# 867.8206787109375,
# 653.9595336914062,
# 706.5844116210938,
# 1845.2354736328125,
# 678.695556640625,
# 629.789306640625,
# 1903.2039794921875,
# 1266.7393798828125,
# 1028.9815673828125,
# 1171.6717529296875,
# 2355.005859375,
# 1475.9554443359375,
# 1039.4718017578125,
# 2116.665771484375,
# 1119.6541748046875,
# 1173.581298828125,
# 1112.3531494140625,
# 3198.95263671875,
# 1218.2261962890625,
# 881.4888305664062,
# 1780.18359375,
# 1494.0528564453125,
# 2317.130859375,
# 944.790771484375,
# 1837.9693603515625,
# 1676.647216796875,
# 1153.56884765625,
# 1394.2275390625,
# 1217.4300537109375,
# 1632.8946533203125,
# 1466.1197509765625,
# 649.606201171875,
# 1705.6063232421875,
# 1602.629638671875,
# 965.0042114257812,
# 840.2964477539062,
# 1253.768310546875,
# 1040.4593505859375,
# 1118.650146484375,
# 895.752197265625,
# 1009.0972290039062,
# 1050.311767578125,
# 737.9634399414062,
# 847.655517578125,
# 1403.7689208984375,
# 809.8704833984375,
# 728.9601440429688,
# 1076.4398193359375,
# 994.2785034179688,
# 1105.5606689453125,
# 836.834228515625,
# 670.4086303710938,
# 866.9713134765625,
# 1348.67138671875,
# 1427.0302734375,
# 574.5767211914062,
# 631.6626586914062,
# 883.01123046875,
# 1703.477294921875,
# 616.1793823242188,
# 595.5425415039062,
# 645.3477783203125,
# 873.533203125,
# 788.886962890625,
# 628.71728515625,
# 1101.282470703125,
# 848.34619140625,
# 598.8041381835938,
# 774.0352783203125,
# 909.3250122070312,
# 1362.206298828125,
# 624.8657836914062,
# 797.0158081054688,
# 1095.828369140625,
# 915.5372924804688,
# 1087.365478515625,
# 1020.8250122070312,
# 1179.5765380859375,
# 921.4820556640625,
# 876.2001953125,
# 655.2490844726562,
# 1081.314697265625,
# 834.46533203125,
# 654.0706787109375,
# 826.7147216796875,
# 975.8614501953125,
# 847.6913452148438,
# 841.3969116210938,
# 1064.9373779296875,
# 1094.2469482421875,
# 1089.5885009765625,
# 1103.01318359375,
# 697.7158203125,
# 916.1978759765625,
# 840.6748046875,
# 819.1939697265625,
# 892.1116333007812,
# 869.578125,
# 1034.25146484375,
# 937.7247314453125,
# 1087.130859375,
# 911.3988037109375,
# 1243.439697265625,
# 645.395751953125,
# 899.6426391601562,
# 957.8511962890625,
# 666.5184936523438,
# 828.8724975585938,
# 804.3256225585938,
# 1243.5615234375,
# 950.2115478515625,
# 767.617919921875,
# 978.0558471679688,
# 701.4450073242188,
# 1056.6805419921875,
# 871.1565551757812,
# 939.1730346679688,
# 879.9314575195312,
# 960.9131469726562,
# 1029.7939453125,
# 992.33935546875,
# 909.7789916992188,
# 1440.3297119140625,
# 1501.7374267578125,
# 616.6642456054688,
# 816.325927734375,
# 1129.3204345703125,
# 712.5908203125,
# 815.90576171875,
# 1155.522705078125,
# 1281.3092041015625,
# 551.3643798828125,
# 1222.32275390625,
# 1059.074462890625,
# 1064.314453125,
# 909.6593017578125,
# 934.6771240234375,
# 1195.8861083984375,
# 1144.683349609375,
# 569.7845458984375,
# 608.5525512695312,
# 814.3442993164062,
# 972.8038940429688,
# 843.1588134765625,
# 968.0856323242188,
# 567.6249389648438,
# 804.4188232421875,
# 939.3048095703125,
# 1554.6689453125,
# 753.0302124023438,
# 886.2919311523438,
# 1262.46826171875,
# 563.0465087890625,
# 805.9310302734375,
# 965.4044799804688,
# 1161.643310546875,
# 649.2041625976562,
# 605.6395263671875,
# 886.86083984375,
# 952.2384033203125,
# 896.97412109375,
# 467.43719482421875,
# 896.807861328125,
# 1747.19189453125,
# 589.6459350585938,
# 773.32861328125,
# 788.3187255859375,
# 1063.55126953125,
# 841.1207275390625,
# 948.5587158203125,
# 1117.176025390625,
# 829.05322265625,
# 1171.447021484375,
# 727.3388671875,
# 1022.4635009765625,
# 835.625244140625,
# 987.8597412109375,
# 1868.3201904296875,
# 846.333740234375,
# 657.3307495117188,
# 1216.4119873046875,
# 619.3923950195312,
# 860.4586181640625,
# 763.4402465820312,
# 1091.283203125,
# 822.9127197265625,
# 764.6991577148438,
# 849.7073974609375,
# 1448.0133056640625,
# 698.4188842773438,
# 625.9132690429688,
# 786.2075805664062,
# 807.2232666015625,
# 899.6130981445312,
# 1170.7327880859375,
# 662.2048950195312,
# 698.0069580078125,
# 1328.022216796875,
# 1026.5772705078125,
# 859.4788818359375,
# 758.8872680664062,
# 729.5748291015625,
# 953.650146484375,
# 676.8128051757812,
# 845.1129760742188,
# 900.9327392578125,
# 747.6217651367188,
# 760.0869750976562,
# 926.4928588867188,
# 817.8319091796875,
# 505.0269470214844,
# 761.3848266601562,
# 519.5186157226562,
# 975.7410278320312,
# 664.3447875976562,
# 658.7672729492188,
# 723.9251098632812,
# 732.84521484375,
# 597.5302124023438,
# 481.27911376953125,
# 652.0601806640625,
# 925.1383666992188,
# 883.1067504882812,
# 688.0881958007812,
# 846.0072631835938,
# 2151.59033203125,
# 882.5692138671875,
# 1117.237548828125,
# 690.2040405273438,
# 1163.3685302734375,
# 951.688232421875,
# 765.1856689453125,
# 727.2150268554688,
# 829.5509643554688,
# 774.9547729492188,
# 797.6380004882812,
# 847.3155517578125,
# 787.1331176757812,
# 975.1605834960938,
# 832.865478515625,
# 735.7088623046875,
# 546.2579345703125,
# 1136.6455078125,
# 1065.8648681640625,
# 524.3801879882812,
# 1294.880859375,
# 821.7955322265625,
# 835.52197265625,
# 955.196533203125,
# 589.7449340820312,
# 910.042724609375,
# 652.9940795898438,
# 599.6616821289062,
# 749.1780395507812,
# 964.7328491210938,
# 861.4756469726562,
# 959.510986328125,
# 1003.881591796875,
# 1021.9716186523438,
# 772.5910034179688,
# 784.2944946289062,
# 970.0698852539062,
# 1078.4052734375,
# 852.68115234375,
# 1074.51220703125,
# 621.2860107421875,
# 891.737060546875,
# 577.3165283203125,
# 827.634521484375,
# 2620.9169921875,
# 710.4802856445312,
# 848.8515014648438,
# 1008.8143920898438,
# 446.4684143066406,
# 684.3878784179688,
# 992.9642333984375,
# 878.7210693359375,
# 1411.445068359375,
# 693.2846069335938,
# 803.7333374023438,
# 701.5598754882812,
# 802.2883911132812,
# 831.8593139648438,
# 785.0073852539062,
# 463.5468444824219,
# 942.166015625,
# 856.7046508789062,
# 682.2247314453125,
# 800.2568359375,
# 695.0390014648438,
# 1424.8509521484375,
# 427.8134460449219,
# 732.2869262695312,
# 5158.21337890625,
# 883.9251098632812,
# 1067.196044921875,
# 866.1146240234375,
# 856.745849609375,
# 867.992431640625,
# 746.7634887695312,
# 1721.8358154296875,
# 487.9523620605469,
# 897.8888549804688,
# 1032.6436767578125,
# 904.5062866210938,
# 906.2689819335938,
# 540.2607421875,
# 689.1746826171875,
# 1293.0531005859375,
# 1005.2581176757812,
# 1072.2381591796875,
# 782.3192138671875,
# 675.0213012695312,
# 825.9989013671875,
# 812.5424194335938,
# 998.5546264648438,
# 849.5194091796875,
# 654.004638671875,
# 1140.2239990234375,
# 866.6475219726562,
# 1355.1846923828125,
# 545.4801635742188,
# 635.9306030273438,
# 884.9283447265625,
# 1174.235595703125,
# 937.4755249023438,
# 936.0767211914062,
# 568.9751586914062,
# 715.1256713867188,
# 795.932861328125,
# 1024.1248779296875,
# 811.9052734375,
# 855.3817749023438,
# 1189.3614501953125,
# 861.6270751953125,
# 826.9114990234375,
# 671.2879638671875,
# 934.6588745117188,
# 767.5823364257812,
# 617.9939575195312,
# 755.9030151367188,
# 763.79833984375,
# 824.2681274414062,
# 832.9794311523438,
# 818.7592163085938,
# 879.4254760742188,
# 503.9783020019531,
# 703.4434204101562,
# 859.189208984375,
# 790.3778686523438,
# 1007.6243286132812,
# 938.5406494140625,
# 887.8638305664062,
# 836.9105224609375,
# 663.6840209960938,
# 1070.0849609375,
# 546.6370849609375,
# 574.477783203125,
# 829.0420532226562,
# 615.4573364257812,
# 1244.2724609375,
# 508.7908020019531,
# 868.1992797851562,
# 807.7850952148438,
# 758.8502197265625,
# 1001.4832763671875,
# 786.920654296875,
# 1184.1929931640625,
# 771.4932250976562,
# 856.1156005859375,
# 660.3882446289062,
# 958.9193115234375,
# 573.5364990234375,
# 846.7906494140625,
# 953.3707885742188,
# 950.7867431640625,
# 709.5142211914062,
# 748.5901489257812,
# 1012.9360961914062,
# 828.4060668945312,
# 849.9644775390625,
# 866.9594116210938,
# 900.7673950195312,
# 689.19873046875,
# 694.3583374023438,
# 1019.1826171875,
# 656.1817626953125,
# 896.9815063476562,
# 654.5267333984375,
# 683.068603515625,
# 900.41162109375,
# 710.6552734375,
# 963.9064331054688,
# 1352.7520751953125,
# 1373.0882568359375,
# 515.5867919921875,
# 712.1648559570312,
# 824.0884399414062,
# 690.4365234375,
# 832.82275390625,
# 860.7421875,
# 658.8477783203125,
# 704.542724609375,
# 924.1444702148438,
# 960.5240478515625,
# 573.3253784179688,
# 1100.631591796875,
# 543.7592163085938,
# 807.88720703125,
# 848.1754760742188,
# 926.6936645507812,
# 1069.057373046875,
# 430.6297912597656,
# 1015.4404296875,
# 539.96728515625,
# 890.1343994140625,
# 679.5020751953125,
# 878.1302490234375,
# 878.850830078125,
# 715.95361328125,
# 796.8713989257812,
# 751.84033203125,
# 718.18212890625,
# 979.8828735351562,
# 650.2867431640625,
# 566.120361328125,
# 546.0941162109375,
# 910.8356323242188,
# 842.1604614257812,
# 1085.169189453125,
# 742.7329711914062,
# 619.5264892578125,
# 1163.121337890625,
# 761.260498046875,
# 1167.1572265625,
# 695.82080078125,
# 1278.8031005859375,
# 711.0211181640625,
# 1210.7305908203125,
# 732.0658569335938,
# 728.71533203125,
# 803.9044189453125,
# 520.3148803710938,
# 593.88623046875,
# 895.9268798828125,
# 664.4247436523438,
# 626.4946899414062,
# 1179.428466796875,
# 1214.3731689453125,
# 339.9708251953125,
# 1714.9962158203125,
# 523.30615234375,
# 481.43048095703125,
# 558.629638671875,
# 986.3773193359375,
# 682.0673217773438,
# 621.0997924804688,
# 855.1820678710938,
# 975.221435546875,
# 1451.0069580078125,
# 480.7479553222656,
# 551.9545288085938,
# 985.6773681640625,
# 681.1975708007812,
# 1076.93212890625,
# 698.2135620117188,
# 1116.004638671875,
# 777.1611938476562,
# 658.609375,
# 779.6732177734375,
# 1180.701904296875,
# 464.4540100097656,
# 934.245361328125,
# 727.9982299804688,
# 1025.722900390625,
# 1115.09619140625,
# 407.6225280761719,
# 386.9679870605469,
# 850.2476196289062,
# 666.00830078125,
# 652.9464111328125,
# 626.7218627929688,
# 771.9812622070312,
# 677.462646484375,
# 664.3594360351562,
# 704.3058471679688,
# 916.8582763671875,
# 802.0921020507812,
# 710.39501953125,
# 739.4449462890625,
# 1050.12451171875,
# 613.3965454101562,
# 946.1360473632812,
# 724.5616455078125,
# 943.3932495117188,
# 767.3475952148438,
# 704.876708984375,
# 924.9428100585938,
# 1034.83642578125,
# 833.6016235351562,
# 1153.8538818359375,
# 467.5194396972656,
# 852.4378662109375,
# 919.9740600585938,
# 662.03466796875,
# 744.3118286132812,
# 1166.5281982421875,
# 586.4025268554688,
# 520.97021484375,
# 897.0084838867188,
# 1157.21875,
# 768.8095092773438,
# 398.5562744140625,
# 918.9293823242188,
# 817.9992065429688,
# 967.5926513671875,
# 530.0310668945312,
# 919.3833618164062,
# 742.443603515625,
# 988.1799926757812,
# 731.7852172851562,
# 761.578369140625,
# 1008.073974609375,
# 709.0914916992188,
# 882.70166015625,
# 870.1171264648438,
# 737.1661376953125,
# 1098.24072265625,
# 545.1170654296875,
# 1053.2957763671875,
# 859.8707885742188,
# 757.0259399414062,
# 471.5657043457031,
# 1051.298828125,
# 1030.9403076171875,
# 1088.4732666015625,
# 668.677734375,
# 914.1998901367188,
# 745.67822265625,
# 765.6599731445312,
# 1506.3992919921875,
# 421.9208679199219,
# 855.0719604492188,
# 592.0996704101562,
# 963.8743286132812,
# 810.3479614257812,
# 987.6783447265625,
# 639.8329467773438,
# 1239.9896240234375,
# 482.36572265625,
# 703.5194702148438,
# 678.3405151367188,
# 562.8907470703125,
# 1583.94140625,
# 742.7283935546875,
# 882.9835815429688,
# 605.3820190429688,
# 775.125732421875,
# 509.2740173339844,
# 641.940673828125,
# 912.8461303710938,
# 756.3480834960938,
# 641.5891723632812,
# 672.0589599609375,
# 719.7642822265625,
# 1526.848388671875,
# 1005.0181884765625,
# 1261.5919189453125,
# 721.1166381835938,
# 855.725341796875,
# 884.5299072265625,
# 527.7303466796875,
# 1348.739501953125,
# 723.9068603515625,
# 766.7432861328125,
# 875.1494140625,
# 995.2428588867188,
# 920.9061889648438,
# 648.167724609375,
# 969.503173828125,
# 1142.216796875,
# 763.7213745117188,
# 967.0961303710938,
# 667.4359130859375,
# 719.8604736328125,
# 1054.5474853515625,
# 949.2220458984375,
# 481.3385314941406,
# 802.737548828125,
# 1022.3131713867188,
# 818.1286010742188,
# 669.20263671875,
# 747.9344482421875,
# 953.4087524414062,
# 1330.6798095703125,
# 610.2728881835938,
# 807.1588745117188,
# 804.76806640625,
# 560.5902709960938,
# 738.3173828125,
# 1356.5374755859375,
# 1206.3648681640625,
# 943.8385009765625,
# 677.1376342773438,
# 696.2202758789062,
# 784.6300659179688,
# 993.9351196289062,
# 744.8345947265625,
# 1190.5091552734375,
# 552.9240112304688,
# 1056.302978515625,
# 1284.3184814453125,
# 517.743408203125,
# 604.6539916992188,
# 869.4720458984375,
# 862.5435791015625,
# 590.8944702148438,
# 925.9552612304688,
# 887.0360107421875,
# 468.87646484375,
# 928.9950561523438,
# 716.3253784179688,
# 923.8152465820312,
# 1179.9415283203125,
# 540.03759765625,
# 553.5798950195312,
# 710.2076416015625,
# 919.6000366210938,
# 518.121826171875,
# 1028.0797119140625,
# 1052.904052734375,
# 545.9179077148438,
# 688.0609130859375,
# 1002.7564697265625,
# 859.3961181640625,
# 963.7432250976562,
# 1096.5638427734375,
# 611.2752075195312,
# 685.702880859375,
# 560.88037109375,
# 666.8467407226562,
# 817.5629272460938,
# 1403.9788818359375,
# 459.3920593261719,
# 411.26605224609375,
# 628.51416015625,
# 683.818359375,
# 696.812744140625,
# 528.74365234375,
# 1146.12255859375,
# 959.2017822265625,
# 855.5285034179688,
# 969.4176635742188,
# 779.095947265625,
# 890.4243774414062,
# 679.9545288085938,
# 912.0035400390625,
# 920.7489013671875,
# 871.409423828125,
# 1005.0394287109375,
# 2582.068359375,
# 484.69976806640625,
# 787.83056640625,
# 766.021240234375,
# 1764.342041015625,
# 475.84857177734375,
# 910.0560302734375,
# 2325.822265625,
# 727.3821411132812,
# 468.032470703125,
# 897.0778198242188,
# 1397.23046875,
# 584.4425048828125,
# 601.4443359375,
# 987.7114868164062,
# 489.33514404296875,
# 780.8699951171875,
# 806.2118530273438,
# 763.9467163085938,
# 1028.539306640625,
# 479.3460388183594,
# 716.7088012695312,
# 805.7637939453125,
# 941.9854736328125,
# 772.0669555664062,
# 734.7158813476562,
# 810.4349975585938,
# 804.9229125976562,
# 822.8679809570312,
# 667.5958862304688,
# 968.1509399414062,
# 947.5408935546875,
# 882.371826171875,
# 519.698486328125,
# 643.4796142578125,
# 1741.13427734375,
# 446.1800231933594,
# 456.1290588378906,
# 954.9816284179688,
# 1130.924072265625,
# 780.8755493164062,
# 732.103515625,
# 746.782958984375,
# 734.2316284179688,
# 983.333740234375,
# 1054.0894775390625,
# 1089.56494140625,
# 576.460205078125,
# 623.791259765625,
# 1132.11376953125,
# 1794.1595458984375,
# 488.7888488769531,
# 305.5507507324219,
# 808.0859375,
# 873.5501708984375,
# 753.3573608398438,
# 1077.119384765625,
# 506.3011779785156,
# 949.2708740234375,
# 866.1943969726562,
# 1290.2044677734375,
# 703.4461669921875,
# 985.463623046875,
# 642.25927734375,
# 707.2022094726562,
# 566.8457641601562,
# 763.3123168945312,
# 685.5098266601562,
# 1752.94970703125,
# 606.6007690429688,
# 415.5464172363281,
# 689.9266357421875,
# 589.6196899414062,
# 1167.9571533203125,
# 973.0280151367188,
# 675.9298706054688,
# 716.0196533203125,
# 686.5238037109375,
# 1277.7406005859375,
# 701.8536376953125,
# 495.1384582519531,
# 761.9027709960938,
# 799.7692260742188,
# 1008.5530395507812,
# 682.483154296875,
# 853.4503173828125,
# 1130.12646484375,
# 496.3697814941406,
# 727.0750122070312,
# 1605.1107177734375,
# 784.4710083007812,
# 636.6697387695312,
# 752.6251831054688,
# 1152.8785400390625,
# 585.952880859375,
# 876.9829711914062,
# 633.2854614257812,
# 963.8150024414062,
# 735.018310546875,
# 843.7410278320312,
# 900.6412353515625,
# 851.6700439453125,
# 910.8934326171875,
# 1070.36767578125,
# 923.0408325195312,
# 787.1475830078125,
# 1799.114990234375,
# 433.81512451171875,
# 572.1919555664062,
# 897.5492553710938,
# 1414.6187744140625,
# 885.618408203125,
# 589.6636352539062,
# 712.8634643554688,
# 657.9698486328125,
# 847.6701049804688,
# 1311.5787353515625,
# 385.4211120605469,
# 809.6806030273438,
# 604.005859375,
# 891.6417846679688,
# 1298.048583984375,
# 1252.520263671875,
# 834.000244140625,
# 1106.106689453125,
# 1020.9566040039062,
# 656.6616821289062,
# 753.8475341796875,
# 1257.0406494140625,
# 534.2134399414062,
# 1239.6414794921875,
# 722.2665405273438,
# 783.6409301757812,
# 669.8585815429688,
# 1055.030029296875,
# 735.04248046875,
# 743.2853393554688,
# 704.3764038085938,
# 768.7964477539062,
# 892.4042358398438,
# 818.6140747070312,
# 796.5022583007812,
# 836.5963134765625,
# 569.5504760742188,
# 1125.1905517578125,
# 491.874267578125,
# 764.1861572265625,
# 649.4307861328125,
# 809.1119384765625,
# 643.8395385742188,
# 947.6741333007812,
# 705.4000244140625,
# 1143.4266357421875,
# 1118.828857421875,
# 759.5537719726562,
# 813.3031005859375,
# 613.0634155273438,
# 812.1060791015625,
# 960.3189697265625,
# 620.5757446289062,
# 1494.1741943359375,
# 367.6302490234375,
# 591.0336303710938,
# 684.67724609375,
# 1321.3511962890625,
# 754.3209838867188,
# 1011.7866821289062,
# 681.4475708007812,
# 761.9481811523438,
# 592.314208984375,
# 799.839111328125,
# 685.4644775390625,
# 1008.4854736328125,
# 693.7921142578125,
# 914.884765625,
# 666.4976196289062,
# 1129.5169677734375,
# 633.4850463867188,
# 738.0291137695312,
# 1194.4298095703125,
# 673.5108032226562,
# 799.605224609375,
# 762.7374267578125,
# 696.5431518554688,
# 870.10498046875,
# 840.9796142578125,
# 576.0892333984375,
# 916.4024047851562,
# 773.445556640625,
# 716.0121459960938,
# 613.0717163085938,
# 694.6631469726562,
# 1090.3232421875,
# 593.4190063476562,
# 814.2227172851562,
# 824.03955078125,
# 1086.470703125,
# 680.045166015625,
# 917.7774658203125,
# 831.1434936523438,
# 928.4364013671875,
# 783.8753662109375,
# 878.9888916015625,
# 866.4613647460938,
# 786.5410766601562,
# 644.202392578125,
# 675.7412719726562,
# 720.6571655273438,
# 933.7185668945312,
# 595.4633178710938,
# 1022.9950561523438,
# 559.0010986328125,
# 686.7000122070312,
# 1193.95751953125,
# 712.4766235351562,
# 1269.3717041015625,
# 525.0159912109375,
# 816.302978515625,
# 957.4103393554688,
# 427.9372863769531,
# 633.552001953125,
# 1243.7015380859375,
# 591.8353881835938,
# 1021.19091796875,
# 721.8046264648438,
# 802.2111206054688,
# 753.69677734375,
# 989.1007080078125,
# 723.2296752929688,
# 741.56201171875,
# 832.7872314453125,
# 531.409423828125,
# 1007.04541015625,
# 1794.082763671875,
# 770.334228515625,
# 845.62353515625,
# 715.0026245117188,
# 668.3185424804688,
# 718.3051147460938,
# 566.906005859375,
# 617.186279296875,
# 822.5654907226562,
# 969.90673828125,
# 783.7207641601562,
# 1013.799072265625,
# 828.2540893554688,
# 1229.77880859375,
# 672.4478759765625,
# 1028.8924560546875,
# 612.9700927734375,
# 553.2850952148438,
# 737.3674926757812,
# 1092.3447265625,
# 654.2156372070312,
# 905.3837890625,
# 663.0137329101562,
# 775.5296020507812,
# 622.8930053710938,
# 757.455078125,
# 964.9312133789062,
# 787.4859008789062,
# 830.96240234375,
# 1068.396728515625,
# 2162.966064453125,
# 1065.4222412109375,
# 568.3877563476562,
# 888.0352783203125,
# 981.5528564453125,
# 744.2957763671875,
# 1186.2984619140625,
# 678.3160400390625,
# 689.7968139648438,
# 758.4711303710938,
# 755.9274291992188,
# 964.9467163085938,
# 743.6163940429688,
# 871.3994750976562,
# 1022.6425170898438,
# 1328.1024169921875,
# 575.5404052734375,
# 723.2604370117188,
# 604.4789428710938,
# 1073.15673828125,
# 1020.8927612304688,
# 680.9537353515625,
# 934.5352783203125,
# 666.4315185546875,
# 899.36669921875,
# 836.5098266601562,
# 434.6972961425781,
# 1475.869140625,
# 512.90087890625,
# 669.3197021484375,
# 822.2484741210938,
# 968.52001953125,
# 732.674072265625,
# 895.2238159179688,
# 703.4391479492188,
# 709.9982299804688,
# 407.3122253417969,
# 1108.068115234375,
# 827.3250122070312,
# 1173.3175048828125,
# 471.847412109375,
# 769.2962646484375,
# 599.5919799804688,
# 661.0949096679688,
# 894.0603637695312,
# 634.8850708007812,
# 1947.685546875,
# 522.796142578125,
# 1681.798583984375,
# 458.1685485839844,
# 564.7498779296875
#     ]
#     plotReward(rewardSeq, eps=300, filename="picture/train_loss(CHS).eps") #pre
    #endregion

    # plotStateMSE(isSave=True)
    plotStepMSE(isSave=True)
    # plot3DTraj(isSave=True)

    plt.show()
